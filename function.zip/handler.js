'use strict';          
const AWS = require('aws-sdk');
const S3 = new AWS.S3({});

module.exports.prepareSubmission = (event, context, callback) => {
  console.log(event, context);
  // let getObjPromise = S3.getObject({
  //   Bucket: event.Bucket,
  //   Key: event.Key}).promise();
  
  // getObjPromise.then(function(data){
  //   JSZip.loadAsync(data.Body).then(function (zip) {
  //     let files = _.filter(zip.files, (file)=>{
  //       if(!file.dir) {
  //         file.async("string").then((text)=>{
  //           fs.writeFile('/temp/'+file.name, text, 'utf8', (err) => {
  //             if (err) throw err;
  //             console.log(file.name + ' has been saved!');
  //           });
  //         })
  //       }
  //       return !file.dir;
  //     });
  //   });
  
  //  callback(null, {});
  // }, (err, res) => {
  //   console.log(err, res)
  //   callback(err, res)
  // });
  const response = {
    statusCode: 200,
    body: JSON.stringify({
      message: 'Success!',
      input: event,
    }),
  };

  callback(null, response);

  // Use this code if you don't use the http event with the LAMBDA-PROXY integration
  // callback(null, { message: 'Go Serverless v1.0! Your function executed successfully!', event });
};
